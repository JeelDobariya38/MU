/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author HP
 */
@WebServlet(name = "login", urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String usr = request.getParameter("username");
        String pwd = request.getParameter("password");
        
        if (usr.toLowerCase().equals("mu") && pwd.toLowerCase().equals("java")) {
            HttpSession sc = request.getSession();
            sc.setAttribute("user", usr);
            response.sendRedirect("welcome");
        } else {
            request.getRequestDispatcher("index.html").include(request, response);
            out.println("Sorry Your Credentials Are Wrong!!! <br/>");
            out.println("Correct Credentials: MU, JAVA!!!");
        }
    }

}
